# Store App Icons

This zip contains modern outlined SVG icons for your customer store app design.

## Suggested Flutter package

Add this to pubspec.yaml:

```yaml
dependencies:
  flutter_svg: ^2.0.10
```

## Suggested asset path

Copy the `icons/` folder to:

```text
assets/icons/
```

Then add:

```yaml
flutter:
  assets:
    - assets/icons/
```

## Usage example

```dart
import 'package:flutter_svg/flutter_svg.dart';

SvgPicture.asset(
  'assets/icons/cart.svg',
  width: 24,
  height: 24,
  colorFilter: const ColorFilter.mode(
    Color(0xffD41445),
    BlendMode.srcIn,
  ),
);
```

For dark mode, use your blue accent color:

```dart
const Color(0xff3D7BFF)
```

For inactive icons, use:

```dart
const Color(0xff9E9E9E)
```
